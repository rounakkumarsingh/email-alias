(() => {
  // src/lib/browser.js
  var api = globalThis.browser ?? globalThis.chrome;

  // src/lib/alias.js
  var ALIAS_ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789";
  var MAX_TAG = 24;
  var TWO_LEVEL_SUFFIXES = new Set([
    "co.in",
    "gov.in",
    "ac.in",
    "org.in",
    "net.in",
    "nic.in",
    "edu.in",
    "co.uk",
    "org.uk",
    "ac.uk",
    "gov.uk",
    "com.au",
    "co.jp",
    "com.br",
    "co.nz",
    "com.sg",
    "co.za"
  ]);
  function randomPart(length, rng = (buf) => crypto.getRandomValues(buf)) {
    const n = ALIAS_ALPHABET.length;
    const limit = 256 - 256 % n;
    const out = [];
    while (out.length < length) {
      const buf = new Uint8Array(length * 2);
      rng(buf);
      for (const b of buf) {
        if (b < limit)
          out.push(ALIAS_ALPHABET[b % n]);
        if (out.length === length)
          break;
      }
    }
    return out.join("");
  }
  function sanitizeTag(raw) {
    return (raw || "").toLowerCase().replace(/[^a-z0-9-]/g, "").replace(/^-+|-+$/g, "").slice(0, MAX_TAG).replace(/-+$/g, "");
  }
  function tagFromHost(hostname) {
    const parts = (hostname || "").toLowerCase().replace(/^www\./, "").split(".").filter(Boolean);
    if (parts.length === 0)
      return "";
    if (parts.length === 1)
      return sanitizeTag(parts[0]);
    const lastTwo = parts.slice(-2).join(".");
    const label = TWO_LEVEL_SUFFIXES.has(lastTwo) && parts.length >= 3 ? parts[parts.length - 3] : parts[parts.length - 2];
    return sanitizeTag(label);
  }
  function buildAlias(tag, random, domain) {
    return `${tag}.${random}@${domain}`;
  }
  var ALIAS_PATTERN = /^([a-z0-9-]{1,24})\.([a-z0-9]+)@((?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,})$/;
  function parseAlias(text) {
    const m = ALIAS_PATTERN.exec((text || "").trim().toLowerCase());
    return m ? { tag: m[1], random: m[2], domain: m[3] } : null;
  }
  function isValidDomain(domain) {
    return /^(?=.{3,253}$)([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/i.test(domain || "");
  }

  // src/lib/fill.js
  function fillEmailField(value, allowSearch) {
    const usable = (el) => el && el.tagName === "INPUT" && !el.disabled && !el.readOnly && ["email", "text", ""].includes((el.getAttribute("type") || "").toLowerCase());
    let el = document.activeElement;
    if (!usable(el)) {
      if (!allowSearch)
        return false;
      el = document.querySelector('input[type="email"]:not([disabled]):not([readonly])') || Array.from(document.querySelectorAll("input")).find((i) => usable(i) && /mail/i.test([i.name, i.id, i.autocomplete, i.placeholder].join(" ")));
    }
    if (!el)
      return false;
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    setter.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.focus();
    return true;
  }
  async function fillInTab(tabId, value, frameId) {
    const target = frameId === undefined ? { tabId, allFrames: true } : { tabId, frameIds: [frameId] };
    const first = await api.scripting.executeScript({ target, func: fillEmailField, args: [value, false] });
    if (first.some((r) => r.result))
      return true;
    const second = await api.scripting.executeScript({
      target: { tabId, frameIds: [frameId ?? 0] },
      func: fillEmailField,
      args: [value, true]
    });
    return second.some((r) => r.result);
  }

  // src/lib/registry.js
  function addEntry(registry, { alias, site = "", note = "" }, now = () => new Date().toISOString()) {
    const parsed = parseAlias(alias);
    if (!parsed)
      throw new Error("Not a valid alias: " + alias);
    const key = alias.trim().toLowerCase();
    if (registry.some((e) => e.alias === key))
      return registry;
    const t = now();
    const entry = {
      alias: key,
      tag: parsed.tag,
      site: String(site || "").replace(/^www\./, ""),
      created: t,
      updated: t,
      status: "active",
      note: String(note || "")
    };
    return [entry, ...registry];
  }
  function patch(registry, alias, fields, now) {
    const key = alias.trim().toLowerCase();
    return registry.map((e) => e.alias === key ? { ...e, ...fields, updated: now() } : e);
  }
  function setStatus(registry, alias, status, now = () => new Date().toISOString()) {
    if (status !== "active" && status !== "blocked")
      throw new Error("Bad status: " + status);
    return patch(registry, alias, { status }, now);
  }
  function search(registry, query) {
    const q = String(query || "").trim().toLowerCase();
    if (!q)
      return registry;
    return registry.filter((e) => [e.alias, e.tag, e.site, e.note, e.status].some((f) => f.toLowerCase().includes(q)));
  }
  function blockedAliases(registry) {
    return registry.filter((e) => e.status === "blocked").map((e) => e.alias).sort();
  }

  // src/lib/labels.js
  var NEEDS = "needs-creating";
  var CREATED = "created";
  var LABEL_MODES = ["manual", "bridge"];
  var iso = () => new Date().toISOString();
  function ensureTag(labels, tag, now = iso) {
    if (!tag || labels[tag])
      return labels;
    return { ...labels, [tag]: { status: NEEDS, updated: now() } };
  }
  function reconcile(labels, registry, categories = [], now = iso) {
    let out = labels;
    for (const tag of [...categories, ...registry.map((e) => e.tag)])
      out = ensureTag(out, tag, now);
    return out;
  }
  function setLabelStatus(labels, tag, status, now = iso) {
    if (status !== NEEDS && status !== CREATED)
      throw new Error("Bad label status: " + status);
    if (labels[tag]?.status === status)
      return labels;
    return { ...labels, [tag]: { status, updated: now() } };
  }
  function markCreated(labels, tags, now = iso) {
    return tags.reduce((acc, t) => setLabelStatus(acc, t, CREATED, now), labels);
  }

  // src/lib/settings.js
  var DEFAULTS = {
    domain: "rounakkumarsingh.com",
    length: 6,
    fixed: ["hello@rounakkumarsingh.com", "rounak@rounakkumarsingh.com"],
    categories: ["fin", "govt"],
    spamFolder: "Spam",
    labelMode: "manual"
  };
  var EMAIL = /^[a-z0-9._+-]+@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/;
  function parseList(value) {
    if (Array.isArray(value))
      return value.map((v) => String(v).trim()).filter(Boolean);
    return String(value || "").split(/[\s,]+/).map((v) => v.trim()).filter(Boolean);
  }
  function validateSettings(raw) {
    const errors = {};
    const value = {};
    const domain = String(raw.domain ?? "").trim().toLowerCase();
    if (!isValidDomain(domain))
      errors.domain = "Enter a domain like example.com, without @ or https://.";
    value.domain = domain;
    const length = Number(raw.length);
    if (!Number.isInteger(length) || length < 5 || length > 12) {
      errors.length = "Random part length must be a whole number from 5 to 12.";
    }
    value.length = length;
    const fixed = parseList(raw.fixed).map((a) => a.toLowerCase());
    const badFixed = fixed.filter((a) => !EMAIL.test(a));
    if (badFixed.length)
      errors.fixed = `Not a valid address: ${badFixed[0]}`;
    value.fixed = [...new Set(fixed)];
    const categories = parseList(raw.categories).map((c) => c.toLowerCase());
    const badCat = categories.find((c) => sanitizeTag(c) !== c || !c);
    if (badCat)
      errors.categories = `"${badCat}" is not a valid tag. Use a-z, 0-9 and hyphens, up to ${MAX_TAG} characters.`;
    value.categories = [...new Set(categories)];
    const spam = String(raw.spamFolder ?? "").trim();
    if (!spam || spam.length > 100)
      errors.spamFolder = "Enter a folder or label name (up to 100 characters).";
    else if (/["\\\u0000-\u001f]|\$\{/.test(spam))
      errors.spamFolder = "The name can't contain \", \\, ${ or control characters.";
    value.spamFolder = spam;
    const mode = raw.labelMode ?? DEFAULTS.labelMode;
    if (!LABEL_MODES.includes(mode))
      errors.labelMode = "Choose Manual or Bridge linker.";
    value.labelMode = mode;
    return { ok: Object.keys(errors).length === 0, errors, value };
  }

  // src/lib/storage.js
  async function getSettings() {
    const stored = await api.storage.sync.get(DEFAULTS);
    const checked = validateSettings(stored);
    const out = { ...DEFAULTS, ...stored };
    for (const k of Object.keys(checked.errors))
      out[k] = DEFAULTS[k];
    return out;
  }
  async function getRegistry() {
    const { registry = [] } = await api.storage.local.get("registry");
    return registry;
  }
  async function saveRegistry(registry) {
    await api.storage.local.set({ registry });
  }
  async function getLastCopiedHash() {
    const { lastCopiedHash = "" } = await api.storage.local.get("lastCopiedHash");
    return lastCopiedHash;
  }
  async function setLinkerStatus({ ok, message }) {
    await api.storage.local.set({ linkerStatus: { ok, message, at: new Date().toISOString() } });
  }
  async function getLabels() {
    const { labels = {} } = await api.storage.local.get("labels");
    return labels;
  }
  async function saveLabels(labels) {
    await api.storage.local.set({ labels });
  }
  async function syncedLabels() {
    const [labels, registry, settings] = await Promise.all([getLabels(), getRegistry(), getSettings()]);
    const next = reconcile(labels, registry, settings.categories);
    if (next !== labels)
      await saveLabels(next);
    return next;
  }

  // src/lib/linker.js
  var HOST_NAME = "com.rounakkumarsingh.alias_maker";

  class LinkerError extends Error {
  }
  function explain(err) {
    const msg = String(err?.message || err || "");
    if (/not found|no such native|Specified native messaging host/i.test(msg)) {
      return "Native host not installed. Run native/install.sh and restart the browser.";
    }
    if (/forbidden|access to the specified native messaging host/i.test(msg)) {
      return "The browser is not allowed to use the host. Re-run native/install.sh.";
    }
    if (/exited|disconnected|closed/i.test(msg)) {
      return "The native host stopped unexpectedly. Check that python3 is installed.";
    }
    return msg || "Could not reach the native host.";
  }
  var defaultSend = (message) => api.runtime.sendNativeMessage(HOST_NAME, message);
  async function callHost(message, send = defaultSend) {
    let reply;
    try {
      reply = await send(message);
    } catch (err) {
      throw new LinkerError(explain(err));
    }
    if (!reply || reply.ok !== true)
      throw new LinkerError(reply?.error || "The host returned an unexpected reply.");
    return reply;
  }
  async function ensureLabels(names, send) {
    if (!names.length)
      return { created: [], existing: [], message: "No labels to sync." };
    const r = await callHost({ type: "ensure_labels", names }, send);
    const message = r.created.length ? `Created ${r.created.length} label${r.created.length === 1 ? "" : "s"}: ${r.created.join(", ")}.` : "All labels already exist in Proton.";
    return { created: r.created, existing: r.existing, message };
  }
  function isNewTag(registryBefore, tag) {
    return !registryBefore.some((e) => e.tag === tag);
  }

  // src/lib/record.js
  async function recordAlias(alias, site) {
    const before = await getRegistry();
    const next = addEntry(before, { alias, site });
    if (next === before)
      return next;
    await saveRegistry(next);
    const tag = parseAlias(alias).tag;
    let labels = ensureTag(await getLabels(), tag);
    try {
      const { labelMode } = await getSettings();
      if (labelMode === "bridge" && isNewTag(before, tag)) {
        const r = await ensureLabels([tag]);
        labels = markCreated(labels, [tag]);
        await setLinkerStatus({ ok: true, message: r.message });
      }
    } catch (err) {
      await setLinkerStatus({ ok: false, message: err.message || String(err) });
    }
    await saveLabels(labels);
    return next;
  }

  // src/lib/sieve.js
  function escapeSieve(s) {
    return String(s).replace(/\\/g, "\\\\").replace(/"/g, "\\\"");
  }
  var q = (s) => `"${escapeSieve(s)}"`;
  var list = (items) => items.length === 1 ? q(items[0]) : `[${items.map(q).join(", ")}]`;
  function generateSieve(settings, registry) {
    const blocked = blockedAliases(registry);
    const out = [];
    out.push('require ["fileinto", "variables"];', "");
    out.push("# 1. Blocked aliases: drop silently.");
    if (blocked.length) {
      out.push(`if address :is "to" ${list(blocked)} {`, "    discard;", "    stop;", "}");
    } else {
      out.push("# (none blocked)");
    }
    out.push("");
    out.push("# 2. Fixed addresses: deliver normally.");
    if (settings.fixed.length) {
      out.push(`if address :is "to" ${list(settings.fixed)} {`, "    stop;", "}");
    } else {
      out.push("# (none configured)");
    }
    out.push("");
    out.push("# 3. Aliases: label by the tag before the first dot.");
    out.push('if address :localpart :matches "to" "*.*" {', '    fileinto "${1}";', "    stop;", "}", "");
    out.push("# 4. Anything else at the domain was guessed by a spammer.");
    out.push(`if address :domain :is "to" ${q(settings.domain)} {`, `    fileinto ${q(settings.spamFolder)};`, "}", "");
    return out.join(`
`);
  }
  async function hashScript(script) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(script));
    return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }

  // src/lib/sieve-state.js
  async function sieveState() {
    const script = generateSieve(await getSettings(), await getRegistry());
    const hash = await hashScript(script);
    const last = await getLastCopiedHash();
    return { script, hash, stale: hash !== last, neverCopied: last === "" };
  }

  // src/popup/popup.js
  var $ = (id) => document.getElementById(id);
  var settings;
  var host = "";
  var rand = "";
  var currentTag = () => sanitizeTag($("tag").value);
  var currentAlias = () => currentTag() ? buildAlias(currentTag(), rand, settings.domain) : "";
  function say(message, kind = "ok") {
    $("status").textContent = message;
    $("status").dataset.kind = kind;
  }
  function render() {
    const tag = currentTag();
    $("preview").classList.toggle("empty", !tag);
    document.querySelector(".p-tag").textContent = tag || "tag";
    document.querySelector(".p-rand").textContent = rand;
    document.querySelector(".p-domain").textContent = "@" + settings.domain;
    $("rand").textContent = rand;
    $("fill").disabled = !tag;
    $("copy").disabled = !tag;
  }
  async function renderList() {
    const registry = await getRegistry();
    const items = search(registry, $("search").value);
    const list = $("list");
    list.replaceChildren();
    if (items.length === 0) {
      const li = document.createElement("li");
      li.className = "empty-note";
      li.textContent = registry.length ? "No matches." : "Aliases you fill or copy show up here.";
      list.append(li);
    }
    for (const e of items.slice(0, 50)) {
      const li = document.createElement("li");
      li.className = e.status;
      const copy = document.createElement("button");
      copy.type = "button";
      copy.className = "copy";
      copy.title = "Copy " + e.alias;
      const addr = document.createElement("span");
      addr.className = "addr";
      addr.textContent = e.alias;
      const site = document.createElement("span");
      site.className = "site";
      site.textContent = e.site;
      copy.append(addr, site);
      copy.addEventListener("click", async () => {
        await navigator.clipboard.writeText(e.alias);
        say("Copied " + e.alias);
      });
      const block = document.createElement("button");
      block.type = "button";
      block.className = "small";
      const blocked = e.status === "blocked";
      block.textContent = blocked ? "Unblock" : "Block";
      block.setAttribute("aria-label", `${block.textContent} ${e.alias}`);
      block.addEventListener("click", async () => {
        await saveRegistry(setStatus(await getRegistry(), e.alias, blocked ? "active" : "blocked"));
        say(blocked ? "Unblocked." : "Blocked. Copy the updated filter script from Registry & settings.");
        await renderList();
        await renderStale();
      });
      li.append(copy, block);
      list.append(li);
    }
  }
  async function renderStale() {
    const s = await sieveState();
    $("stale").hidden = !s.stale || s.neverCopied;
  }
  async function showLabelNotice(tag) {
    const notice = $("label-notice");
    notice.hidden = true;
    if (!tag || settings.labelMode !== "manual")
      return;
    const labels = await syncedLabels();
    if (labels[tag]?.status !== NEEDS)
      return;
    $("notice-tag").textContent = tag;
    notice.dataset.tag = tag;
    notice.hidden = false;
  }
  async function copyAlias() {
    const alias = currentAlias();
    if (!alias)
      return;
    await navigator.clipboard.writeText(alias);
    await recordAlias(alias, host);
    say("Copied. Paste it into the signup form.");
    await renderList();
    await showLabelNotice(currentTag());
  }
  async function fillAlias() {
    const alias = currentAlias();
    if (!alias)
      return;
    const [tab] = await api.tabs.query({ active: true, currentWindow: true });
    try {
      if (await fillInTab(tab.id, alias)) {
        await recordAlias(alias, host);
        say("Filled. 1Password will offer to save the login when you sign up.");
        await renderList();
        await showLabelNotice(currentTag());
        return;
      }
      await navigator.clipboard.writeText(alias);
      await recordAlias(alias, host);
      say("No email field found on this page. Alias copied instead.", "err");
    } catch {
      await navigator.clipboard.writeText(alias);
      await recordAlias(alias, host);
      say("This page can't be filled. Alias copied instead.", "err");
    }
    await renderList();
    await showLabelNotice(currentTag());
  }
  async function init() {
    settings = await getSettings();
    rand = randomPart(settings.length);
    try {
      const [tab] = await api.tabs.query({ active: true, currentWindow: true });
      const url = new URL(tab.url);
      if (url.protocol === "http:" || url.protocol === "https:")
        host = url.hostname;
    } catch {
      host = "";
    }
    const tagInput = $("tag");
    tagInput.value = tagFromHost(host);
    for (const cat of settings.categories) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "chip";
      b.textContent = cat;
      b.addEventListener("click", () => {
        tagInput.value = cat;
        render();
        tagInput.focus();
      });
      $("chips").append(b);
    }
    render();
    await renderList();
    await renderStale();
    tagInput.focus();
    tagInput.select();
    tagInput.addEventListener("input", render);
    tagInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter")
        fillAlias();
    });
    $("regen").addEventListener("click", () => {
      rand = randomPart(settings.length);
      render();
    });
    $("fill").addEventListener("click", fillAlias);
    $("copy").addEventListener("click", copyAlias);
    $("search").addEventListener("input", renderList);
    $("notice-copy").addEventListener("click", async () => {
      await navigator.clipboard.writeText($("label-notice").dataset.tag);
      say("Label name copied.");
    });
    $("notice-done").addEventListener("click", async () => {
      const tag = $("label-notice").dataset.tag;
      await saveLabels(markCreated(await getLabels(), [tag]));
      $("label-notice").hidden = true;
      say(`Marked "${tag}" as created.`);
    });
    for (const id of ["open-options", "stale"]) {
      $(id).addEventListener("click", (e) => {
        e.preventDefault();
        api.runtime.openOptionsPage();
      });
    }
  }
  init();
})();
