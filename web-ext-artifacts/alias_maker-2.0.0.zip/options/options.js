(() => {
  // src/lib/alias.js
  var MAX_TAG = 24;
  var TWO_LEVEL_SUFFIXES = new Set([
    "co.in",
    "gov.in",
    "ac.in",
    "org.in",
    "net.in",
    "nic.in",
    "edu.in",
    "co.uk",
    "org.uk",
    "ac.uk",
    "gov.uk",
    "com.au",
    "co.jp",
    "com.br",
    "co.nz",
    "com.sg",
    "co.za"
  ]);
  function sanitizeTag(raw) {
    return (raw || "").toLowerCase().replace(/[^a-z0-9-]/g, "").replace(/^-+|-+$/g, "").slice(0, MAX_TAG).replace(/-+$/g, "");
  }
  var ALIAS_PATTERN = /^([a-z0-9-]{1,24})\.([a-z0-9]+)@((?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,})$/;
  function parseAlias(text) {
    const m = ALIAS_PATTERN.exec((text || "").trim().toLowerCase());
    return m ? { tag: m[1], random: m[2], domain: m[3] } : null;
  }
  function isValidDomain(domain) {
    return /^(?=.{3,253}$)([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/i.test(domain || "");
  }

  // src/lib/registry.js
  var REGISTRY_VERSION = 1;
  function patch(registry, alias, fields, now) {
    const key = alias.trim().toLowerCase();
    return registry.map((e) => e.alias === key ? { ...e, ...fields, updated: now() } : e);
  }
  function setStatus(registry, alias, status, now = () => new Date().toISOString()) {
    if (status !== "active" && status !== "blocked")
      throw new Error("Bad status: " + status);
    return patch(registry, alias, { status }, now);
  }
  function setNote(registry, alias, note, now = () => new Date().toISOString()) {
    return patch(registry, alias, { note: String(note || "") }, now);
  }
  function removeEntry(registry, alias) {
    const key = alias.trim().toLowerCase();
    return registry.filter((e) => e.alias !== key);
  }
  function search(registry, query) {
    const q = String(query || "").trim().toLowerCase();
    if (!q)
      return registry;
    return registry.filter((e) => [e.alias, e.tag, e.site, e.note, e.status].some((f) => f.toLowerCase().includes(q)));
  }
  function blockedAliases(registry) {
    return registry.filter((e) => e.status === "blocked").map((e) => e.alias).sort();
  }
  function tagsOf(registry) {
    return [...new Set(registry.map((e) => e.tag))].sort();
  }
  function exportRegistry(registry, now = () => new Date().toISOString(), labels = {}) {
    return JSON.stringify({ app: "alias-maker", version: REGISTRY_VERSION, exported: now(), entries: registry, labels }, null, 2);
  }
  function normaliseEntry(raw) {
    if (!raw || typeof raw !== "object")
      throw new Error("Entry is not an object");
    const parsed = parseAlias(raw.alias);
    if (!parsed)
      throw new Error("Invalid alias: " + JSON.stringify(raw.alias));
    if (raw.status !== "active" && raw.status !== "blocked")
      throw new Error("Invalid status for " + raw.alias);
    const created = Date.parse(raw.created);
    if (Number.isNaN(created))
      throw new Error("Invalid created date for " + raw.alias);
    const updated = raw.updated !== undefined ? Date.parse(raw.updated) : created;
    if (Number.isNaN(updated))
      throw new Error("Invalid updated date for " + raw.alias);
    return {
      alias: raw.alias.trim().toLowerCase(),
      tag: parsed.tag,
      site: typeof raw.site === "string" ? raw.site : "",
      created: new Date(created).toISOString(),
      updated: new Date(updated).toISOString(),
      status: raw.status,
      note: typeof raw.note === "string" ? raw.note : ""
    };
  }
  function parseImport(text) {
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error("That file is not valid JSON.");
    }
    if (!data || data.app !== "alias-maker" || !Array.isArray(data.entries)) {
      throw new Error("That file is not an Alias Maker export.");
    }
    if (data.version !== REGISTRY_VERSION)
      throw new Error("Unsupported export version: " + data.version);
    return data.entries.map(normaliseEntry);
  }
  function mergeRegistry(current, incoming) {
    const map = new Map(current.map((e) => [e.alias, e]));
    let added = 0;
    let changed = 0;
    for (const e of incoming) {
      const have = map.get(e.alias);
      if (!have) {
        map.set(e.alias, e);
        added++;
      } else if (Date.parse(e.updated) > Date.parse(have.updated)) {
        map.set(e.alias, e);
        changed++;
      }
    }
    const registry = [...map.values()].sort((a, b) => Date.parse(b.created) - Date.parse(a.created));
    return { registry, added, changed };
  }

  // src/lib/labels.js
  var NEEDS = "needs-creating";
  var CREATED = "created";
  var LABEL_MODES = ["manual", "bridge"];
  var iso = () => new Date().toISOString();
  function ensureTag(labels, tag, now = iso) {
    if (!tag || labels[tag])
      return labels;
    return { ...labels, [tag]: { status: NEEDS, updated: now() } };
  }
  function reconcile(labels, registry, categories = [], now = iso) {
    let out = labels;
    for (const tag of [...categories, ...registry.map((e) => e.tag)])
      out = ensureTag(out, tag, now);
    return out;
  }
  function setLabelStatus(labels, tag, status, now = iso) {
    if (status !== NEEDS && status !== CREATED)
      throw new Error("Bad label status: " + status);
    if (labels[tag]?.status === status)
      return labels;
    return { ...labels, [tag]: { status, updated: now() } };
  }
  function markCreated(labels, tags, now = iso) {
    return tags.reduce((acc, t) => setLabelStatus(acc, t, CREATED, now), labels);
  }
  var pendingTags = (labels) => Object.keys(labels).filter((t) => labels[t].status === NEEDS).sort();
  var tagList = (labels) => Object.keys(labels).sort().map((tag) => ({ tag, status: labels[tag].status }));
  function mergeLabels(current, incoming) {
    const out = { ...current };
    for (const [tag, v] of Object.entries(incoming)) {
      if (!out[tag] || Date.parse(v.updated) > Date.parse(out[tag].updated))
        out[tag] = v;
    }
    return out;
  }
  function parseLabels(raw) {
    if (raw === undefined)
      return {};
    if (!raw || typeof raw !== "object" || Array.isArray(raw))
      throw new Error("Labels must be an object.");
    const out = {};
    for (const [tag, v] of Object.entries(raw)) {
      if (!tag || sanitizeTag(tag) !== tag)
        throw new Error("Invalid label tag: " + JSON.stringify(tag));
      if (!v || v.status !== NEEDS && v.status !== CREATED)
        throw new Error("Invalid label status for " + tag);
      const t = Date.parse(v.updated);
      if (Number.isNaN(t))
        throw new Error("Invalid label date for " + tag);
      out[tag] = { status: v.status, updated: new Date(t).toISOString() };
    }
    return out;
  }

  // src/lib/settings.js
  var DEFAULTS = {
    domain: "rounakkumarsingh.com",
    length: 6,
    fixed: ["hello@rounakkumarsingh.com", "rounak@rounakkumarsingh.com"],
    categories: ["fin", "govt"],
    spamFolder: "Spam",
    labelMode: "manual"
  };
  var EMAIL = /^[a-z0-9._+-]+@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/;
  function parseList(value) {
    if (Array.isArray(value))
      return value.map((v) => String(v).trim()).filter(Boolean);
    return String(value || "").split(/[\s,]+/).map((v) => v.trim()).filter(Boolean);
  }
  function validateSettings(raw) {
    const errors = {};
    const value = {};
    const domain = String(raw.domain ?? "").trim().toLowerCase();
    if (!isValidDomain(domain))
      errors.domain = "Enter a domain like example.com, without @ or https://.";
    value.domain = domain;
    const length = Number(raw.length);
    if (!Number.isInteger(length) || length < 5 || length > 12) {
      errors.length = "Random part length must be a whole number from 5 to 12.";
    }
    value.length = length;
    const fixed = parseList(raw.fixed).map((a) => a.toLowerCase());
    const badFixed = fixed.filter((a) => !EMAIL.test(a));
    if (badFixed.length)
      errors.fixed = `Not a valid address: ${badFixed[0]}`;
    value.fixed = [...new Set(fixed)];
    const categories = parseList(raw.categories).map((c) => c.toLowerCase());
    const badCat = categories.find((c) => sanitizeTag(c) !== c || !c);
    if (badCat)
      errors.categories = `"${badCat}" is not a valid tag. Use a-z, 0-9 and hyphens, up to ${MAX_TAG} characters.`;
    value.categories = [...new Set(categories)];
    const spam = String(raw.spamFolder ?? "").trim();
    if (!spam || spam.length > 100)
      errors.spamFolder = "Enter a folder or label name (up to 100 characters).";
    else if (/["\\\u0000-\u001f]|\$\{/.test(spam))
      errors.spamFolder = "The name can't contain \", \\, ${ or control characters.";
    value.spamFolder = spam;
    const mode = raw.labelMode ?? DEFAULTS.labelMode;
    if (!LABEL_MODES.includes(mode))
      errors.labelMode = "Choose Manual or Bridge linker.";
    value.labelMode = mode;
    return { ok: Object.keys(errors).length === 0, errors, value };
  }

  // src/lib/browser.js
  var api = globalThis.browser ?? globalThis.chrome;

  // src/lib/storage.js
  async function getSettings() {
    const stored = await api.storage.sync.get(DEFAULTS);
    const checked = validateSettings(stored);
    const out = { ...DEFAULTS, ...stored };
    for (const k of Object.keys(checked.errors))
      out[k] = DEFAULTS[k];
    return out;
  }
  async function saveSettings(settings) {
    await api.storage.sync.set(settings);
  }
  async function getRegistry() {
    const { registry = [] } = await api.storage.local.get("registry");
    return registry;
  }
  async function saveRegistry(registry) {
    await api.storage.local.set({ registry });
  }
  async function getLastCopiedHash() {
    const { lastCopiedHash = "" } = await api.storage.local.get("lastCopiedHash");
    return lastCopiedHash;
  }
  async function setLastCopiedHash(hash) {
    await api.storage.local.set({ lastCopiedHash: hash });
  }
  async function getLinkerStatus() {
    const { linkerStatus = null } = await api.storage.local.get("linkerStatus");
    return linkerStatus;
  }
  async function setLinkerStatus({ ok, message }) {
    await api.storage.local.set({ linkerStatus: { ok, message, at: new Date().toISOString() } });
  }
  async function getLabels() {
    const { labels = {} } = await api.storage.local.get("labels");
    return labels;
  }
  async function saveLabels(labels) {
    await api.storage.local.set({ labels });
  }
  async function syncedLabels() {
    const [labels, registry, settings] = await Promise.all([getLabels(), getRegistry(), getSettings()]);
    const next = reconcile(labels, registry, settings.categories);
    if (next !== labels)
      await saveLabels(next);
    return next;
  }

  // src/lib/modeswitch.js
  async function switchLabelMode({ from, to, labels, ensure }) {
    if (from === to || to !== "bridge")
      return { labels, ran: false, ok: true, message: "" };
    const tags = pendingTags(labels);
    if (!tags.length)
      return { labels, ran: false, ok: true, message: "No labels were waiting to be created." };
    try {
      const r = await ensure(tags);
      return { labels: markCreated(labels, tags), ran: true, ok: true, message: r.message };
    } catch (err) {
      return { labels, ran: true, ok: false, message: err.message || String(err) };
    }
  }

  // src/lib/linker.js
  var HOST_NAME = "com.rounakkumarsingh.alias_maker";

  class LinkerError extends Error {
  }
  function explain(err) {
    const msg = String(err?.message || err || "");
    if (/not found|no such native|Specified native messaging host/i.test(msg)) {
      return "Native host not installed. Run native/install.sh and restart the browser.";
    }
    if (/forbidden|access to the specified native messaging host/i.test(msg)) {
      return "The browser is not allowed to use the host. Re-run native/install.sh.";
    }
    if (/exited|disconnected|closed/i.test(msg)) {
      return "The native host stopped unexpectedly. Check that python3 is installed.";
    }
    return msg || "Could not reach the native host.";
  }
  var defaultSend = (message) => api.runtime.sendNativeMessage(HOST_NAME, message);
  async function callHost(message, send = defaultSend) {
    let reply;
    try {
      reply = await send(message);
    } catch (err) {
      throw new LinkerError(explain(err));
    }
    if (!reply || reply.ok !== true)
      throw new LinkerError(reply?.error || "The host returned an unexpected reply.");
    return reply;
  }
  async function ping(send) {
    const r = await callHost({ type: "ping" }, send);
    return `Connected to Bridge (${r.labels} label${r.labels === 1 ? "" : "s"}).`;
  }
  async function ensureLabels(names, send) {
    if (!names.length)
      return { created: [], existing: [], message: "No labels to sync." };
    const r = await callHost({ type: "ensure_labels", names }, send);
    const message = r.created.length ? `Created ${r.created.length} label${r.created.length === 1 ? "" : "s"}: ${r.created.join(", ")}.` : "All labels already exist in Proton.";
    return { created: r.created, existing: r.existing, message };
  }

  // src/lib/sieve.js
  function escapeSieve(s) {
    return String(s).replace(/\\/g, "\\\\").replace(/"/g, "\\\"");
  }
  var q = (s) => `"${escapeSieve(s)}"`;
  var list = (items) => items.length === 1 ? q(items[0]) : `[${items.map(q).join(", ")}]`;
  function generateSieve(settings, registry) {
    const blocked = blockedAliases(registry);
    const out = [];
    out.push('require ["fileinto", "variables"];', "");
    out.push("# 1. Blocked aliases: drop silently.");
    if (blocked.length) {
      out.push(`if address :is "to" ${list(blocked)} {`, "    discard;", "    stop;", "}");
    } else {
      out.push("# (none blocked)");
    }
    out.push("");
    out.push("# 2. Fixed addresses: deliver normally.");
    if (settings.fixed.length) {
      out.push(`if address :is "to" ${list(settings.fixed)} {`, "    stop;", "}");
    } else {
      out.push("# (none configured)");
    }
    out.push("");
    out.push("# 3. Aliases: label by the tag before the first dot.");
    out.push('if address :localpart :matches "to" "*.*" {', '    fileinto "${1}";', "    stop;", "}", "");
    out.push("# 4. Anything else at the domain was guessed by a spammer.");
    out.push(`if address :domain :is "to" ${q(settings.domain)} {`, `    fileinto ${q(settings.spamFolder)};`, "}", "");
    return out.join(`
`);
  }
  async function hashScript(script) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(script));
    return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }

  // src/lib/sieve-state.js
  async function sieveState() {
    const script = generateSieve(await getSettings(), await getRegistry());
    const hash = await hashScript(script);
    const last = await getLastCopiedHash();
    return { script, hash, stale: hash !== last, neverCopied: last === "" };
  }
  async function copyScript() {
    const { script, hash } = await sieveState();
    await navigator.clipboard.writeText(script);
    await setLastCopiedHash(hash);
    return script;
  }

  // src/options/options.js
  var $ = (id) => document.getElementById(id);
  var TEXT_FIELDS = ["domain", "length", "fixed", "categories", "spamFolder"];
  var FIELDS = [...TEXT_FIELDS, "labelMode"];
  var selectedMode = () => document.querySelector("input[name=labelMode]:checked")?.value;
  function say(id, message, kind = "ok") {
    $(id).textContent = message;
    $(id).dataset.kind = kind;
  }
  async function loadSettings() {
    const s = await getSettings();
    $("domain").value = s.domain;
    $("length").value = s.length;
    $("fixed").value = s.fixed.join(`
`);
    $("categories").value = s.categories.join(", ");
    $("spamFolder").value = s.spamFolder;
    for (const r of document.querySelectorAll("input[name=labelMode]"))
      r.checked = r.value === s.labelMode;
    $("linker").hidden = s.labelMode !== "bridge";
  }
  $("settings").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const raw = { ...Object.fromEntries(TEXT_FIELDS.map((f) => [f, $(f).value])), labelMode: selectedMode() };
    const { ok, errors, value } = validateSettings(raw);
    for (const f of FIELDS) {
      $("e-" + f).textContent = errors[f] || "";
      $(f).setAttribute("aria-invalid", errors[f] ? "true" : "false");
    }
    if (!ok) {
      say("settings-status", "Fix the highlighted fields.", "err");
      $(FIELDS.find((f) => errors[f])).focus();
      return;
    }
    const previous = await getSettings();
    await saveSettings(value);
    say("settings-status", "Settings saved.");
    await loadSettings();
    const sw = await switchLabelMode({
      from: previous.labelMode,
      to: value.labelMode,
      labels: await syncedLabels(),
      ensure: (names) => ensureLabels(names)
    });
    if (sw.ran) {
      await saveLabels(sw.labels);
      await setLinkerStatus({ ok: sw.ok, message: sw.message });
      await showLinkerStatus();
    }
    await renderAll();
  });
  async function renderRegistry() {
    const registry = await getRegistry();
    const rows = $("rows");
    rows.replaceChildren();
    const items = search(registry, $("search").value);
    if (!items.length) {
      const tr = document.createElement("tr");
      const td = document.createElement("td");
      td.colSpan = 6;
      td.className = "empty-note";
      td.textContent = registry.length ? "No matches." : "No aliases yet. Fill or copy one from the popup.";
      tr.append(td);
      rows.append(tr);
    }
    for (const e of items) {
      const tr = document.createElement("tr");
      tr.className = e.status;
      const cell = (text, cls) => {
        const td = document.createElement("td");
        td.textContent = text;
        if (cls)
          td.className = cls;
        return td;
      };
      tr.append(cell(e.alias, "mono"), cell(e.site), cell(e.created.slice(0, 10)), cell(e.status));
      const noteTd = document.createElement("td");
      const note = document.createElement("input");
      note.value = e.note;
      note.setAttribute("aria-label", "Note for " + e.alias);
      note.addEventListener("change", async () => {
        await saveRegistry(setNote(await getRegistry(), e.alias, note.value));
      });
      noteTd.append(note);
      const actions = document.createElement("td");
      const btn = (label, fn) => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "small";
        b.textContent = label;
        b.setAttribute("aria-label", `${label} ${e.alias}`);
        b.addEventListener("click", fn);
        return b;
      };
      const blocked = e.status === "blocked";
      actions.append(btn(blocked ? "Unblock" : "Block", async () => {
        await saveRegistry(setStatus(await getRegistry(), e.alias, blocked ? "active" : "blocked"));
        await renderAll();
      }), " ", btn("Copy", () => navigator.clipboard.writeText(e.alias)), " ", btn("Delete", async () => {
        if (!confirm(`Remove ${e.alias} from the registry? A deleted alias is no longer blocked in the script.`))
          return;
        await saveRegistry(removeEntry(await getRegistry(), e.alias));
        await renderAll();
      }));
      tr.append(noteTd, actions);
      rows.append(tr);
    }
  }
  async function renderSieve() {
    const s = await sieveState();
    $("script").textContent = s.script;
    $("stale").hidden = !s.stale;
    $("stale").textContent = s.neverCopied ? "Not copied yet" : "Out of date";
  }
  async function renderLabels() {
    const labels = await syncedLabels();
    const pending = pendingTags(labels);
    const badge = $("labels-badge");
    badge.hidden = pending.length === 0;
    badge.textContent = `${pending.length} still need${pending.length === 1 ? "s" : ""} creating`;
    const rows = $("label-rows");
    rows.replaceChildren();
    for (const { tag, status } of tagList(labels)) {
      const tr = document.createElement("tr");
      const name = document.createElement("td");
      name.className = "mono";
      name.textContent = tag;
      const st = document.createElement("td");
      const pill = document.createElement("span");
      const done = status === CREATED;
      pill.className = "pill" + (done ? " done" : "");
      pill.textContent = done ? "Created" : "Needs creating";
      st.append(pill);
      const actions = document.createElement("td");
      const btn = (label, fn) => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "small";
        b.textContent = label;
        b.setAttribute("aria-label", `${label}: ${tag}`);
        b.addEventListener("click", fn);
        return b;
      };
      actions.append(btn(done ? "Mark as needs creating" : "Mark created", async () => {
        await saveLabels(setLabelStatus(await getLabels(), tag, done ? NEEDS : CREATED));
        await renderLabels();
      }), " ", btn("Copy name", async () => {
        await navigator.clipboard.writeText(tag);
        say("labels-status", `Copied "${tag}".`);
      }));
      tr.append(name, st, actions);
      rows.append(tr);
    }
  }
  async function renderAll() {
    await renderRegistry();
    await renderLabels();
    await renderSieve();
  }
  $("search").addEventListener("input", renderRegistry);
  $("copy-script").addEventListener("click", async () => {
    try {
      await copyScript();
      say("sieve-status", "Script copied.");
    } catch {
      say("sieve-status", "Could not write to the clipboard.", "err");
    }
    await renderSieve();
  });
  $("export").addEventListener("click", async () => {
    const blob = new Blob([exportRegistry(await getRegistry(), undefined, await syncedLabels())], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `alias-registry-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  });
  $("import").addEventListener("click", () => $("import-file").click());
  $("import-file").addEventListener("change", async (ev) => {
    const file = ev.target.files[0];
    ev.target.value = "";
    if (!file)
      return;
    try {
      const text = await file.text();
      const incoming = parseImport(text);
      const incomingLabels = parseLabels(JSON.parse(text).labels);
      const { registry, added, changed } = mergeRegistry(await getRegistry(), incoming);
      await saveRegistry(registry);
      await saveLabels(mergeLabels(await getLabels(), incomingLabels));
      say("registry-status", `Imported: ${added} added, ${changed} updated.`);
      await renderAll();
    } catch (err) {
      say("registry-status", err.message, "err");
    }
  });
  loadSettings().then(renderAll);
  async function showLinkerStatus() {
    const st = await getLinkerStatus();
    if (!st)
      return say("linker-status", "Not used yet.");
    say("linker-status", `${st.message} (${new Date(st.at).toLocaleString()})`, st.ok ? "ok" : "err");
  }
  async function runLinker(action, button) {
    button.disabled = true;
    say("linker-status", "Working...");
    try {
      const message = await action();
      await setLinkerStatus({ ok: true, message });
    } catch (err) {
      await setLinkerStatus({ ok: false, message: err.message });
    }
    button.disabled = false;
    await showLinkerStatus();
  }
  $("sync-labels").addEventListener("click", (e) => runLinker(async () => {
    const labels = await syncedLabels();
    const r = await ensureLabels([...new Set([...tagsOf(await getRegistry()), ...pendingTags(labels)])].sort());
    await saveLabels(markCreated(labels, [...r.created, ...r.existing]));
    await renderLabels();
    return r.message;
  }, e.currentTarget));
  $("check-linker").addEventListener("click", (e) => runLinker(() => ping(), e.currentTarget));
  showLinkerStatus();
})();
